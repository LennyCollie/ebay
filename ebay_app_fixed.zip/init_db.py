from app import db
db.create_all()
print("Datenbank erfolgreich erstellt.")